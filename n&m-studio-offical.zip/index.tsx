
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Menu, X, ChevronRight, ChevronLeft, ArrowLeft, ArrowRight, 
  PenTool, Hammer, Home, Star, FileText, Settings, Shield, 
  Handshake, ClipboardList, Building2, HardHat, 
  Clock, Share2, Printer, CheckCircle2, Layout, Search, 
  Zap, MessageSquare, Image as ImageIcon, BarChart3,
  MapPin, Phone, Mail, FileSignature, CheckCircle, Facebook, Instagram, Youtube, Linkedin,
  Layers, Monitor, Cpu, Coins, SearchCode, Camera, BrainCircuit, NotebookPen, Calculator,
  BookOpen, Calendar, Send, Plus, MessageCircle
} from 'lucide-react';

// --- SEO CONFIG & HEADLESS WP MOCK ---
// Trong thực tế, các biến này sẽ được fetch từ WordPress REST API
const SEO_METADATA = {
  title: "NM Studio | Thiết Kế Kiến Trúc & Thi Công Nội Thất Trọn Gói",
  description: "NM Studio chuyên thiết kế kiến trúc, nội thất và thi công hoàn thiện. Với 15 năm kinh nghiệm và ứng dụng công nghệ CGI, AI tiên tiến.",
  keywords: "thiết kế kiến trúc hà nội, thi công nội thất, diễn họa cgi, kiến trúc sư uy tín"
};

const ZALO_CONFIG = {
  phoneNumber: "0985578385", // Thay số của bạn ở đây
  message: "Chào NM Studio, tôi cần tư vấn về dịch vụ thiết kế/thi công."
};

// --- DATA & CONTENT ---

const NAV_ITEMS = [
  { label: 'VỀ CHÚNG TÔI', href: '#story', view: 'about' },
  { label: 'DỊCH VỤ', href: '#services', view: 'services' },
  { label: 'DỰ ÁN', href: '#projects', view: 'home' },
  { label: 'CẨM NANG', href: '#blog', view: 'handbook' },
  { label: 'LIÊN HỆ', href: '#contact', view: 'contact' },
];

const HERO_IMAGES = [
  "https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&q=80&w=2000"
];

const PROJECT_CATEGORIES = [
  { id: 'all', label: 'Tất cả', header: 'TẤT CẢ DỰ ÁN' },
  { id: 'arch', label: 'Thiết kế kiến trúc', header: 'THIẾT KẾ KIẾN TRÚC' },
  { id: 'interior', label: 'Thiết kế nội thất', header: 'THIẾT KẾ NỘI THẤT' },
  { id: 'construction', label: 'Thi Công', header: 'THI CÔNG HOÀN THIỆN' },
  { id: 'cgi', label: 'Diễn họa CGI', header: 'DIỄN HỌA CGI' },
  { id: 'ai', label: 'Dịch Vụ AI', header: 'SÁNG TẠO BẰNG AI' },
];

const PROJECTS = [
  {
    id: 1,
    title: "Indochine Apartment",
    location: "Hà Nội",
    year: "2024",
    category: "interior",
    type: "Thi công",
    style: "Indochine",
    floors: "1 Tầng",
    area: "85m2",
    description: "Căn hộ phong cách Indochine với sự kết hợp tinh tế giữa nét hoài cổ và hiện đại. Không gian được tối ưu hóa với các chi tiết gỗ truyền thống kết hợp vật liệu cao cấp, tạo nên cảm giác ấm cúng và sang trọng.",
    gallery: [
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1615529328331-f8917597711f?auto=format&fit=crop&q=80&w=1200"
    ]
  },
  {
    id: 2,
    title: "L's Townhouse",
    location: "Hà Nội",
    year: "2023",
    category: "arch",
    type: "Thiết kế",
    style: "Hiện đại",
    floors: "3 Tầng",
    area: "6x18m",
    description: "Nhà phố hiện đại tối ưu không gian và ánh sáng tự nhiên. Thiết kế tập trung vào sự thông thoáng, sử dụng kính cường lực lớn và các khoảng thông tầng đón gió tự nhiên.",
    gallery: [
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&q=80&w=2000"
    ]
  },
  {
    id: 3,
    title: "Modern CGI Visualization",
    location: "Sài Gòn",
    year: "2024",
    category: "cgi",
    type: "Diễn họa",
    style: "Minimalism",
    floors: "2 Tầng",
    area: "120m2",
    description: "Dự án diễn họa CGI chuyên sâu cho không gian tối giản, tập trung vào mô phỏng ánh sáng vật lý chính xác và vật liệu chân thực.",
    gallery: [
      "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600566752355-3979ff1040ad?auto=format&fit=crop&q=80&w=1200"
    ]
  },
  {
    id: 4,
    title: "Minimalist Forest Villa",
    location: "Đà Lạt",
    year: "2024",
    category: "arch",
    type: "Thiết kế",
    style: "Tối giản",
    floors: "2 Tầng",
    area: "350m2",
    description: "Biệt thự nghỉ dưỡng hòa mình vào thiên nhiên, sử dụng vật liệu gỗ và đá tự nhiên.",
    gallery: [
      "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1200"
    ]
  },
  {
    id: 5,
    title: "Eco-Friendly Office",
    location: "Hà Nội",
    year: "2024",
    category: "interior",
    type: "Thiết kế & Thi công",
    style: "Industrial",
    floors: "4 Tầng",
    area: "1200m2",
    description: "Văn phòng xanh hiện đại, tập trung vào không gian mở và sáng tạo.",
    gallery: [
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&q=80&w=1200"
    ]
  },
  {
    id: 6,
    title: "AI Interior Concept",
    location: "Virtual",
    year: "2024",
    category: "ai",
    type: "Sáng tạo AI",
    style: "Futuristic",
    floors: "N/A",
    area: "Virtual",
    description: "Concept nội thất tương lai được tạo ra bằng công nghệ AI tiên tiến của NM Studio.",
    gallery: [
      "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1678286299103-60be78c6680a?auto=format&fit=crop&q=80&w=1200"
    ]
  }
];

const SERVICES_BRIEF = [
  { title: "THIẾT KẾ KIẾN TRÚC", icon: <PenTool className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=600" },
  { title: "THIẾT KẾ NỘI THẤT", icon: <Layout className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=600" },
  { title: "THI CÔNG HOÀN THIỆN", icon: <Hammer className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&q=80&w=600" },
  { title: "TƯ VẤN GIÁM SÁT", icon: <HardHat className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1541888946425-d81bb19480c5?auto=format&fit=crop&q=80&w=600" },
  { title: "DIỄN HOẠ CGI", icon: <Camera className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&q=80&w=600" },
  { title: "SÁNG TẠO BẰNG AI", icon: <Zap className="w-5 h-5"/>, img: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=600" }
];

const PROCESS_DATA = {
  arch: {
    label: "QUY TRÌNH THIẾT KẾ KIẾN TRÚC",
    stages: [
      { title: "GĐ 1", subtitle: "TIẾP NHẬN THÔNG TIN & KHẢO SÁT", desc: "Tiếp nhận yêu cầu, khảo sát hiện trạng đất/công trình và khảo sát nhu cầu chi tiết của gia chủ.", icon: <SearchCode className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "BÁO GIÁ & HỢP ĐỒNG", desc: "Lập báo giá chi tiết, chốt tiến độ và ký kết hợp đồng thiết kế chính thức.", pay: "💰 50% Phí thiết kế", icon: <FileSignature className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "LAYOUT 2D & CONCEPT", desc: "Mặt bằng công năng (2D) và giải giải pháp hình khối kiến trúc (3D). Điều chỉnh tối đa 3 lần.", pay: "💰 30% Phí thiết kế", icon: <PenTool className="w-8 h-8" /> },
      { title: "GĐ 4", subtitle: "HỒ SƠ KỸ THUẬT THI CÔNG", desc: "Triển khai hồ sơ kỹ thuật chi tiết phục vụ xin phép và thi công hoàn thiện.", pay: "💰 20% Bàn giao hồ sơ", icon: <Layout className="w-8 h-8" /> }
    ]
  },
  interior: {
    label: "QUY TRÌNH THIẾT KẾ NỘI THẤT",
    stages: [
      { title: "GĐ 1", subtitle: "KHẢO SÁT & PHÂN TÍCH", desc: "Khảo sát hiện trạng mặt bằng, đo đạc và phân tích thói quen sinh hoạt gia chủ.", icon: <Search className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "BÁO GIÁ & HỢP ĐỒNG", desc: "Đề xuất phương án hợp tác và ký kết hợp đồng thiết kế nội thất.", pay: "💰 50% Phí thiết kế", icon: <Calculator className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "LAYOUT 2D & CONCEPT", desc: "Mặt bằng 2D, Concept Moodboard vật liệu và dựng phối cảnh 3D nội thất.", pay: "💰 30% Phí thiết kế", icon: <ImageIcon className="w-8 h-8" /> },
      { title: "GĐ 4", subtitle: "HỒ SƠ KỸ THUẬT", desc: "Thiết kế hồ sơ kỹ thuật thi công, sản xuất nội thất chi tiết và bàn giao.", pay: "💰 20% Bàn giao hồ sơ", icon: <NotebookPen className="w-8 h-8" /> }
    ]
  },
  construction: {
    label: "THI CÔNG HOÀN THIỆN NỘI THẤT",
    stages: [
      { title: "GĐ 1", subtitle: "CHUẨN BỊ", desc: "Khảo sát đo đạc thực tế, lập dự toán chi tiết và ký hợp đồng thi công.", pay: "💰 50% Tạm ứng thi công", icon: <ClipboardList className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "TRIỂN KHAI THI CÔNG", desc: "Sản xuất nội thất tại xưởng, thi công lắp đặt tại công trình theo tiến độ.", pay: "💰 30% Theo tiến độ", icon: <Hammer className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "HOÀN THIỆN & BÀN GIAO", desc: "Nghiệm thu thẩm mỹ, bàn giao công trình và kích hoạt bảo hành.", pay: "💰 20% Khi bàn giao", icon: <Building2 className="w-8 h-8" /> }
    ]
  },
  supervision: {
    label: "TƯ VẤN GIÁM SÁT",
    stages: [
      { title: "GĐ 1", subtitle: "TIẾP NHẬN & THỐNG NHẤT", desc: "Tiếp nhận hồ sơ thiết kế, xác định phạm vi và lập kế hoạch giám sát.", pay: "💰 40% Tạm ứng", icon: <NotebookPen className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "GIÁM SÁT THI CÔNG", desc: "Kiểm tra thi công theo hồ sơ, ghi nhận báo cáo và kiến nghị điều chỉnh kỹ thuật.", pay: "💰 40% Theo tiến độ", icon: <HardHat className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "NGHIỆM THU & BÀN GIAO", desc: "Tham gia nghiệm thu hoàn thiện và báo cáo đánh giá kết quả giám sát.", pay: "💰 20% Kết thúc HĐ", icon: <CheckCircle2 className="w-8 h-8" /> }
    ]
  },
  cgi: {
    label: "QUY TRÌNH DIỄN HOẠ CGI",
    stages: [
      { title: "GĐ 1", subtitle: "TIẾP NHẬN BRIEF", desc: "Nhận bản vẽ concept, thống nhất số lượng ảnh và mức độ chi tiết thể hiện.", pay: "💰 50% Tạm ứng", icon: <FileText className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "DỰNG HÌNH & ÁNH SÁNG", desc: "Dựng Model 3D không gian, thiết lập vật liệu, ánh sáng và góc máy.", icon: <Layers className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "RENDER & HIỆU CHỈNH", desc: "Render ảnh chất lượng cao và hiệu chỉnh theo phản hồi của khách hàng.", pay: "💰 40% Sau Render", icon: <Camera className="w-8 h-8" /> },
      { title: "GĐ 4", subtitle: "BÀN GIAO", desc: "Bàn giao sản phẩm Final chất lượng cao phục vụ truyền thông.", pay: "💰 10% Quyết toán", icon: <Share2 className="w-8 h-8" /> }
    ]
  },
  ai: {
    label: "SÁNG TẠO BẰNG AI",
    stages: [
      { title: "GĐ 1", subtitle: "TIẾP NHẬN & ĐỊNH HƯỚNG", desc: "Nhận Brief mục tiêu sử dụng, đề xuất hướng concept AI phù hợp.", pay: "💰 50% Tạm ứng", icon: <Zap className="w-8 h-8" /> },
      { title: "GĐ 2", subtitle: "TRIỂN KHAI PHƯƠNG ÁN AI", desc: "Tạo concept & hình ảnh bằng AI chuyên sâu, thử nghiệm nhiều biến thể nhanh.", icon: <BrainCircuit className="w-8 h-8" /> },
      { title: "GĐ 3", subtitle: "TINH CHỈNH & HOÀN THIỆN", desc: "Lọc chọn phương án tốt nhất và tinh chỉnh chi tiết theo phản hồi.", pay: "💰 40% Chốt phương án", icon: <Settings className="w-8 h-8" /> },
      { title: "GĐ 4", subtitle: "BÀN GIAO", desc: "Bàn giao sản phẩm Final và hướng dẫn hỗ trợ sử dụng cho gia chủ.", pay: "💰 10% Quyết toán", icon: <Monitor className="w-8 h-8" /> }
    ]
  }
};

const HANDBOOK_POSTS = [
  {
    id: 1,
    title: "Những điều cần biết trước khi xây nhà lần đầu",
    date: "15/06/2024",
    category: "Kinh nghiệm",
    image: "https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&q=80&w=1200",
    content: `
      Với nhiều chủ đầu tư, xây nhà là một trong những quyết định lớn nhất trong đời. Tuy nhiên, phần lớn các vấn đề phát sinh không đến từ kỹ thuật phức tạp, mà bắt nguồn từ việc chuẩn bị chưa đủ thông tin ngay từ đầu.
      
      Điều đầu tiên cần làm rõ là nhu cầu sử dụng thực tế, không chỉ ở hiện tại mà cả trong 5–10 năm tới. Một ngôi nhà phù hợp cần trả lời được các câu hỏi như: số người sử dụng, thói quen sinh hoạt, nhu cầu mở rộng trong tương lai, mức độ riêng tư cần thiết giữa các không gian.
      
      Tiếp theo là ngân sách thực tế. Ngân sách không chỉ là chi phí xây dựng phần thô hay hoàn thiện, mà còn bao gồm thiết kế, nội thất, chi phí phát sinh và dự phòng. Việc không xác định rõ ngân sách ngay từ đầu thường dẫn đến cắt giảm vội vàng ở giai đoạn cuối, ảnh hưởng trực tiếp đến chất lượng công trình.
      
      Một yếu tố quan trọng khác là vai trò của thiết kế. Thiết kế không chỉ để “xem cho đẹp”, mà là công cụ giúp kiểm soát không gian, chi phí và tiến độ thi công. Công trình không có thiết kế hoặc thiết kế sơ sài thường phát sinh nhiều vấn đề trong quá trình xây dựng.
    `
  },
  {
    id: 2,
    title: "Thiết kế kiến trúc là gì? Hồ sơ thiết kế gồm những gì?",
    date: "10/06/2024",
    category: "Kiến thức",
    image: "https://images.unsplash.com/photo-1503387852521-999d17f03819?auto=format&fit=crop&q=80&w=1200",
    content: `
      Nhiều chủ đầu tư thường hiểu thiết kế kiến trúc đơn giản là bản vẽ mặt bằng và hình phối cảnh. Thực tế, thiết kế kiến trúc là một quá trình nghiên cứu và giải quyết bài toán không gian, chứ không chỉ là hình ảnh.
    `
  },
  {
    id: 3,
    title: "Gỗ tự nhiên và gỗ công nghiệp: hiểu đúng để chọn đúng",
    date: "05/06/2024",
    category: "Vật liệu",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1200",
    content: `
      Trong thi công nội thất, gỗ là vật liệu được sử dụng phổ biến nhất, nhưng cũng là vật liệu gây nhiều hiểu lầm nhất.
    `
  }
];

const SERIES_TIPS = [
  { id: 1, title: "Vì sao cần làm thiết kế trước khi thi công?", desc: "Thiết kế là bước giúp chủ đầu tư nhìn thấy toàn bộ công trình trước khi bỏ tiền xây dựng." },
  { id: 2, title: "Những khoản chi phí thường phát sinh khi thi công nội thất", desc: "Chi phí phát sinh thường đến từ thay đổi nhu cầu giữa chừng, thiết kế chưa đủ chi tiết." },
  { id: 3, title: "AI trong thiết kế: nên dùng ở giai đoạn nào?", desc: "AI phù hợp nhất ở giai đoạn lên ý tưởng nhanh, thử nghiệm phong cách." }
];

// --- COMPONENTS ---

const ZaloButton = () => {
  const zaloUrl = `https://zalo.me/${ZALO_CONFIG.phoneNumber}`;
  return (
    <a 
      href={zaloUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-[60] group flex items-center"
      aria-label="Chat qua Zalo"
    >
      <div className="bg-white text-[#0068FF] px-4 py-2 rounded-full shadow-lg mr-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-4 group-hover:translate-x-0 font-bold text-xs uppercase tracking-widest pointer-events-none">
        Chat Zalo
      </div>
      <div className="w-14 h-14 bg-[#0068FF] rounded-full flex items-center justify-center shadow-2xl animate-bounce hover:scale-110 transition-transform">
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/9/91/Icon_of_Zalo.svg" 
          className="w-8 h-8 invert" 
          alt="Zalo" 
        />
      </div>
    </a>
  );
};

const Counter = ({ target, duration = 1500, suffix = "+" }: { target: number, duration?: number, suffix?: string }) => {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLDivElement>(null);
  const [hasStarted, setHasStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.1 }
    );

    if (elementRef.current) observer.observe(elementRef.current);
    return () => observer.disconnect();
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;

    let startTime: number | null = null;
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const progressFraction = Math.min(progress / duration, 1);
      
      const easeOutQuad = (t: number) => t * (2 - t);
      const easedProgress = easeOutQuad(progressFraction);
      
      const currentCount = Math.floor(easedProgress * target);
      setCount(currentCount);

      if (progress < duration) {
        requestAnimationFrame(animate);
      } else {
        setCount(target);
      }
    };
    requestAnimationFrame(animate);
  }, [hasStarted, target, duration]);

  return (
    <div 
      ref={elementRef} 
      className="text-4xl font-heading font-bold text-[#705d3f] transition-all duration-300"
      style={{ filter: 'drop-shadow(0 2px 2px rgba(0,0,0,0.1))' }}
    >
      {count}{suffix}
    </div>
  );
};

const Header = ({ onNavigate, currentView, onScrollToProjects }: { onNavigate: (view: string) => void, currentView: string, onScrollToProjects: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handle = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handle);
    return () => window.removeEventListener('scroll', handle);
  }, []);

  const transparentViews = ['home', 'project_detail', 'handbook', 'contact'];
  const isSolid = !transparentViews.includes(currentView) || isScrolled;
  const headerBgClass = isSolid ? 'bg-white shadow-md py-3' : 'bg-transparent py-6';
  const textColorClass = isSolid ? 'text-gray-800' : 'text-white';
  const logoClass = isSolid ? '' : 'brightness-0 invert';

  const handleNavClick = (view: string, label: string) => {
    setIsMenuOpen(false);
    if (label === 'DỰ ÁN') {
      onScrollToProjects();
    } else {
      onNavigate(view);
    }
  };

  return (
    <header className={`fixed w-full z-50 transition-all duration-500 ${headerBgClass}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center cursor-pointer z-50" onClick={() => onNavigate('home')}>
          <img 
            src="https://lh3.googleusercontent.com/d/18wUo0JZ3MWDLKqjRqFsS6PB5jDbZYNsA" 
            className={`h-10 md:h-12 transition-all duration-300 ${logoClass}`} 
            alt="N&M Studio Logo" 
          />
        </div>

        <nav className="hidden lg:flex gap-8">
          {NAV_ITEMS.map((item, i) => (
            <a 
              key={i} 
              href={item.href} 
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(item.view || 'home', item.label);
              }}
              className={`text-[11px] font-bold uppercase tracking-widest hover:text-brand-primary transition-colors ${textColorClass} ${currentView === item.view ? 'text-brand-primary' : ''}`}
            >
              {item.label}
            </a>
          ))}
        </nav>

        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)} 
          className={`lg:hidden z-50 p-2 ${textColorClass} transition-transform active:scale-90`}
        >
          {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>

        <div className={`fixed inset-0 bg-white z-40 flex flex-col items-center justify-center gap-8 transition-all duration-500 lg:hidden ${isMenuOpen ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible -translate-y-10'}`}>
           {NAV_ITEMS.map((item, i) => (
            <a 
              key={i} 
              href={item.href} 
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(item.view || 'home', item.label);
              }}
              className="text-2xl font-heading font-bold text-gray-800 uppercase tracking-widest hover:text-brand-primary transition-colors"
            >
              {item.label}
            </a>
          ))}
          <div className="mt-10 flex gap-6">
              <Facebook className="text-gray-400 hover:text-blue-600 cursor-pointer" />
              <Instagram className="text-gray-400 hover:text-pink-600 cursor-pointer" />
              <a href={`tel:${ZALO_CONFIG.phoneNumber}`}><Phone className="text-gray-400 hover:text-green-600 cursor-pointer" /></a>
          </div>
        </div>
      </div>
    </header>
  );
};

const HeroCarousel = () => {
  const [current, setCurrent] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrent((prev) => (prev === HERO_IMAGES.length - 1 ? 0 : prev + 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrent((prev) => (prev === 0 ? HERO_IMAGES.length - 1 : prev - 1));
  }, []);

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000);
    return () => clearInterval(timer);
  }, [nextSlide]);

  return (
    <div className="absolute inset-0 overflow-hidden">
      {HERO_IMAGES.map((img, idx) => (
        <div 
          key={idx} 
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${idx === current ? 'opacity-100' : 'opacity-0'}`}
        >
          <div className="absolute inset-0 animate-breathe">
            <img src={img} className="w-full h-full object-cover" alt={`Thiết kế kiến trúc ${idx + 1}`} />
          </div>
          <div className="absolute inset-0 bg-black/40" />
        </div>
      ))}

      <button 
        onClick={prevSlide}
        className="hidden md:flex absolute left-6 top-1/2 -translate-y-1/2 z-20 p-4 border border-white/20 text-white rounded-full hover:bg-brand-primary hover:border-brand-primary transition-all group"
      >
        <ChevronLeft className="w-8 h-8 group-hover:scale-110 transition-transform" />
      </button>
      <button 
        onClick={nextSlide}
        className="hidden md:flex absolute right-6 top-1/2 -translate-y-1/2 z-20 p-4 border border-white/20 text-white rounded-full hover:bg-brand-primary hover:border-brand-primary transition-all group"
      >
        <ChevronRight className="w-8 h-8 group-hover:scale-110 transition-transform" />
      </button>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 flex gap-3">
        {HERO_IMAGES.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`transition-all duration-500 rounded-full h-1.5 ${idx === current ? 'w-12 bg-brand-primary' : 'w-4 bg-white/30 hover:bg-white/50'}`}
          />
        ))}
      </div>
    </div>
  );
};

const ProjectDetailView = ({ project, onBack, onContact }: { project: any, onBack: () => void, onContact: () => void }) => {
  const [mainImage, setMainImage] = useState(project.gallery[0]);

  return (
    <div className="pt-24 min-h-screen bg-white animate-fadeIn">
      {/* SEO Title Simulation */}
      <title>{`${project.title} | Dự án thực tế NM Studio`}</title>
      <div className="container mx-auto px-6 py-12">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-400 hover:text-brand-primary text-xs font-bold uppercase tracking-widest mb-12 transition-all group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform"/> Quay lại dự án
        </button>

        <div className="flex flex-col lg:flex-row gap-16">
          <div className="w-full lg:w-1/3 space-y-10">
            <div>
               <h1 className="text-4xl md:text-5xl font-heading font-bold text-gray-900 leading-tight mb-4 uppercase">{project.title}</h1>
               <div className="w-16 h-1 bg-brand-primary"></div>
            </div>
            <div className="grid grid-cols-2 gap-y-8 gap-x-4">
              {[
                { label: 'Vị trí', val: project.location },
                { label: 'Năm thực hiện', val: project.year },
                { label: 'Phong cách', val: project.style },
                { label: 'Quy mô', val: project.floors },
                { label: 'Diện tích', val: project.area },
                { label: 'Loại hình', val: project.type }
              ].map((item, i) => (
                <div key={i}>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">{item.label}</p>
                  <p className="text-sm font-bold text-gray-800 uppercase">{item.val}</p>
                </div>
              ))}
            </div>
            <div className="space-y-4">
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Mô tả dự án</p>
              <p className="text-sm text-gray-600 leading-relaxed font-light">{project.description}</p>
            </div>
            <button 
              onClick={onContact}
              className="w-full bg-brand-primary text-white py-4 px-10 text-[11px] font-bold uppercase tracking-widest hover:bg-brand-secondary transition-all shadow-lg active:scale-95"
            >
              LIÊN HỆ NGAY
            </button>
          </div>
          <div className="w-full lg:w-2/3 space-y-6">
            <div className="aspect-video w-full overflow-hidden shadow-2xl bg-gray-100 rounded-sm">
               <img src={mainImage} className="w-full h-full object-cover animate-fadeIn" alt={project.title} />
            </div>
            <div className="grid grid-cols-4 md:grid-cols-6 gap-4">
               {project.gallery.map((img: string, i: number) => (
                 <div key={i} onClick={() => setMainImage(img)} className={`aspect-square overflow-hidden cursor-pointer border-2 transition-all ${mainImage === img ? 'border-brand-primary opacity-100 scale-95' : 'border-transparent opacity-60 hover:opacity-100'}`}>
                    <img src={img} className="w-full h-full object-cover" alt={`Chi tiết dự án ${project.title} ${i}`} />
                 </div>
               ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ContactView = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1000);
  };

  if (submitted) {
    return (
      <div className="pt-24 min-h-screen bg-[#111] flex items-center justify-center px-6">
        <div className="max-w-md w-full text-center space-y-6 bg-[#1a1a1a] p-12 border border-white/5 rounded-sm shadow-2xl animate-fadeIn">
          <div className="w-20 h-20 bg-brand-primary rounded-full flex items-center justify-center mx-auto mb-8 shadow-xl">
             <CheckCircle className="text-white w-10 h-10" />
          </div>
          <h2 className="text-3xl font-heading font-bold text-white uppercase tracking-widest">CẢM ƠN BẠN!</h2>
          <p className="text-gray-400 text-sm font-light leading-relaxed">
            Chúng tôi đã nhận được yêu cầu tư vấn của bạn. NM Studio sẽ liên hệ lại trong thời gian sớm nhất (24-48 giờ làm việc).
          </p>
          <button onClick={() => setSubmitted(false)} className="text-brand-primary text-[10px] font-bold uppercase tracking-widest hover:underline">
            Gửi yêu cầu khác
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-[#111] animate-fadeIn">
      <div className="py-20 text-center px-6">
        <h4 className="text-brand-primary font-bold text-[10px] uppercase tracking-[0.5em] mb-4">CONTACT US</h4>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-white uppercase tracking-widest mb-6">Liên Hệ / Nhận Tư Vấn</h1>
        <div className="w-16 h-1 bg-brand-primary mx-auto"></div>
      </div>

      <div className="container mx-auto px-6 pb-24">
        <div className="max-w-4xl mx-auto bg-[#1a1a1a] p-8 md:p-12 border border-white/5 shadow-2xl rounded-sm">
          <form id="nm-contact" onSubmit={handleSubmit} className="space-y-10">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Tên (bắt buộc)</label>
                <input required placeholder="Tên" className="w-full bg-[#111] border border-white/10 p-4 text-xs text-white focus:border-brand-primary outline-none transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Điện thoại (bắt buộc)</label>
                <input required placeholder="09xx xxx xxx" className="w-full bg-[#111] border border-white/10 p-4 text-xs text-white focus:border-brand-primary outline-none transition-all" />
              </div>
            </div>

            <div className="space-y-4">
              <legend className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Dịch vụ quan tâm</legend>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  'Thiết kế kiến trúc / nội thất',
                  'Thi công hoàn thiện nội thất',
                  'Diễn hoạ kiến trúc (CGI)',
                  'Sáng tạo AI Concept',
                  'Cần tư vấn trọn gói'
                ].map(service => (
                  <label key={service} className="flex items-center gap-3 cursor-pointer group">
                    <input type="checkbox" name="services" value={service} className="w-4 h-4 accent-brand-primary" />
                    <span className="text-[11px] text-gray-400 group-hover:text-white transition-colors">{service}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nội dung dự án</label>
              <textarea required rows={6} placeholder="Ví dụ: Căn hộ 85m2, cần thiết kế nội thất..." className="w-full bg-[#111] border border-white/10 p-4 text-xs text-white focus:border-brand-primary outline-none transition-all resize-none"></textarea>
            </div>

            <div className="text-center">
              <button type="submit" className="bg-[#D49910] hover:bg-[#B3800D] text-black font-bold uppercase tracking-[0.3em] px-12 py-5 text-sm transition-all shadow-xl rounded-sm active:scale-95 flex items-center gap-4 mx-auto">
                GỬI YÊU CẦU <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

const HandbookView = () => {
  const [selectedPost, setSelectedPost] = useState<any>(null);

  if (selectedPost) {
    return (
      <div className="pt-24 min-h-screen bg-white animate-fadeIn">
        <div className="container mx-auto px-6 py-12">
          <button onClick={() => setSelectedPost(null)} className="flex items-center gap-2 text-gray-400 hover:text-brand-primary text-xs font-bold uppercase tracking-widest mb-12 transition-all group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform"/> Quay lại danh sách
          </button>
          <div className="max-w-4xl mx-auto">
            <div className="aspect-[21/9] w-full mb-12 overflow-hidden rounded-sm shadow-xl">
              <img src={selectedPost.image} className="w-full h-full object-cover" alt={selectedPost.title} />
            </div>
            <div className="flex items-center gap-4 mb-6 text-[10px] font-bold text-brand-primary uppercase tracking-widest">
              <span>{selectedPost.date}</span>
              <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
              <span>{selectedPost.category}</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-gray-900 mb-10 uppercase leading-tight">{selectedPost.title}</h1>
            <div className="prose prose-lg max-w-none text-gray-600 font-light leading-loose whitespace-pre-wrap">
              {selectedPost.content}
              <p className="mt-8">NM Studio luôn sẵn sàng hỗ trợ bạn tìm ra giải pháp tối ưu cho không gian sống của mình.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-gray-50 animate-fadeIn">
      <div className="h-[40vh] relative overflow-hidden flex items-center justify-center text-center bg-brand-dark">
         <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=2000" className="absolute inset-0 w-full h-full object-cover grayscale opacity-30" alt="Cẩm nang xây nhà" />
         <div className="relative z-10 px-6">
            <h4 className="text-brand-primary font-bold text-xs uppercase tracking-[0.5em] mb-4">KIẾN THỨC CHUYÊN NGÀNH</h4>
            <h1 className="text-5xl font-heading font-bold text-white mb-6 uppercase tracking-widest">Cẩm Nang NM Studio</h1>
            <div className="w-20 h-1 bg-brand-primary mx-auto"></div>
         </div>
      </div>

      <div className="container mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            {HANDBOOK_POSTS.map(post => (
              <div key={post.id} onClick={() => setSelectedPost(post)} className="bg-white rounded-sm overflow-hidden shadow-md hover:shadow-2xl transition-all cursor-pointer group border border-gray-100">
                <div className="flex flex-col md:flex-row h-full">
                  <div className="md:w-2/5 overflow-hidden">
                    <img src={post.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={post.title} />
                  </div>
                  <div className="md:w-3/5 p-8 flex flex-col justify-center">
                    <div className="text-[10px] font-bold text-brand-primary uppercase tracking-widest mb-4">{post.category} • {post.date}</div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-brand-primary transition-colors uppercase leading-snug">{post.title}</h2>
                    <p className="text-sm text-gray-500 font-light line-clamp-3 leading-relaxed">
                      Tìm hiểu sâu về các kiến thức chuyên ngành được NM Studio đúc kết qua hàng trăm dự án thực tế.
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-1 space-y-8">
            <div className="bg-[#705d3f] p-8 text-white rounded-sm shadow-xl sticky top-32">
              <h3 className="text-sm font-bold uppercase tracking-[0.3em] mb-10 border-b border-white/20 pb-4">Series: Chủ Đầu Tư Cần Biết</h3>
              <div className="space-y-10">
                {SERIES_TIPS.map((tip, idx) => (
                  <div key={tip.id} className="space-y-3">
                    <div className="text-[10px] font-bold text-white/50 uppercase tracking-widest">Bài {idx + 1}</div>
                    <h4 className="text-sm font-bold uppercase tracking-wide leading-snug">{tip.title}</h4>
                    <p className="text-[11px] font-light text-white/70 leading-relaxed">{tip.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AboutUsView = () => (
  <div className="pt-24 min-h-screen bg-[#e0ddd2] flex flex-col lg:flex-row animate-fadeIn">
    <div className="w-full lg:w-1/2 px-8 lg:px-24 py-16 flex flex-col justify-center">
      <h4 className="text-brand-primary font-bold text-xs uppercase tracking-[0.4em] mb-6">GIỚI THIỆU</h4>
      <h1 className="text-4xl md:text-5xl font-heading font-bold mb-10 text-brand-secondary leading-tight uppercase">
        Về NM Studio
      </h1>
      <div className="space-y-6 text-gray-700 leading-relaxed text-sm md:text-base font-light">
        <p>NM Studio là đơn vị hoạt động trong lĩnh vực thiết kế kiến trúc – nội thất, thi công hoàn thiện và diễn hoạ không gian, với hơn 15 năm kinh nghiệm.</p>
        <p>Thành lập từ năm 2007, chúng tôi khởi đầu với đam mê kiến tạo những không gian sống đậm chất nghệ thuật nhưng vẫn đảm bảo tính công năng tối ưu.</p>
        <p>Đến nay, NM Studio đã thực hiện hơn 250 công trình trải dài khắp các tỉnh thành, trở thành đối tác tin cậy của nhiều gia đình và doanh nghiệp.</p>
      </div>
      <div className="mt-12">
          <div className="w-20 h-1 bg-brand-primary"></div>
      </div>
    </div>
    <div className="w-full lg:w-1/2 min-h-[400px] relative overflow-hidden">
      <img 
        src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=2000" 
        className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" 
        alt="NM Studio Office" 
      />
    </div>
  </div>
);

const ServicesView = () => (
  <div className="pt-24 min-h-screen bg-[#f4f1ea] animate-fadeIn">
    <div className="container mx-auto px-6 py-16 text-center max-w-4xl">
      <h4 className="text-brand-primary font-bold text-xs uppercase tracking-[0.4em] mb-6">GIẢI PHÁP TOÀN DIỆN</h4>
      <h1 className="text-4xl md:text-5xl font-heading font-bold mb-8 text-brand-secondary uppercase tracking-widest">
          DỊCH VỤ CỐT LÕI
      </h1>
      <p className="text-gray-600 leading-relaxed text-sm md:text-base font-light mb-12">
          Hệ sinh thái dịch vụ khép kín từ khâu tư vấn, thiết kế, thi công đến ứng dụng công nghệ AI giúp tối ưu thời gian và chi phí cho khách hàng.
      </p>
      <div className="w-20 h-1 bg-brand-primary mx-auto"></div>
    </div>
    <div className="container mx-auto px-6 pb-24 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
       {SERVICES_BRIEF.map((s, i) => (
         <div key={i} className="group relative overflow-hidden h-[400px] shadow-xl rounded-sm">
           <img src={s.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={`Dịch vụ ${s.title}`} />
           <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent flex flex-col justify-end p-8">
             <div className="text-brand-primary mb-4 transform group-hover:-translate-y-2 transition-transform">{s.icon}</div>
             <h3 className="text-xl font-bold text-white uppercase tracking-widest">{s.title}</h3>
           </div>
         </div>
       ))}
    </div>
  </div>
);

const App = () => {
  const [currentView, setCurrentView] = useState('home');
  const [activeProcessTab, setActiveProcessTab] = useState<keyof typeof PROCESS_DATA>('arch');
  const [activeProjectCategory, setActiveProjectCategory] = useState('all');
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [showAllProjects, setShowAllProjects] = useState(false);
  
  const projectsRef = useRef<HTMLDivElement>(null);

  // Cập nhật Metadata SEO giả lập cho Headless WP
  useEffect(() => {
    document.title = SEO_METADATA.title;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', SEO_METADATA.description);
  }, []);

  const navigate = (view: string) => {
    setCurrentView(view);
    setSelectedProject(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToProjects = () => {
    if (currentView !== 'home') {
      setCurrentView('home');
      setTimeout(() => {
        projectsRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 300);
    } else {
      projectsRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const openProjectDetail = (project: any) => {
    setSelectedProject(project);
    setCurrentView('project_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredProjects = activeProjectCategory === 'all' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === activeProjectCategory);

  const visibleProjects = showAllProjects ? filteredProjects : filteredProjects.slice(0, 3);
  const activeHeader = PROJECT_CATEGORIES.find(c => c.id === activeProjectCategory)?.header || 'TẤT CẢ DỰ ÁN';

  return (
    <div className="font-sans text-gray-900 selection:bg-brand-primary selection:text-white antialiased">
      <Header onNavigate={navigate} currentView={currentView} onScrollToProjects={scrollToProjects} />
      
      {/* Floating Zalo Button */}
      <ZaloButton />

      {currentView === 'home' && (
        <>
          <section className="relative h-screen flex items-center justify-center text-white overflow-hidden">
            <HeroCarousel />
            <div className="relative z-10 text-center px-6 max-w-4xl">
              <h1 className="text-4xl md:text-7xl font-heading font-bold mb-6 leading-tight animate-fadeIn" style={{ animationDelay: '0.2s' }}>
                Kiến tạo không gian <br className="hidden md:block"/> sống hoàn mỹ
              </h1>
              <p className="text-sm md:text-lg text-gray-200 mb-10 max-w-2xl mx-auto font-light leading-relaxed animate-fadeIn" style={{ animationDelay: '0.4s' }}>
                Chuyên gia thiết kế, thi công và diễn hoạ với 15 năm kinh nghiệm thực chiến tại Hà Nội và toàn quốc.
              </p>
              <div className="flex flex-col md:flex-row gap-4 justify-center animate-fadeIn" style={{ animationDelay: '0.6s' }}>
                <button 
                  onClick={scrollToProjects} 
                  className="bg-brand-primary py-4 px-10 font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all shadow-xl active:scale-95"
                >
                  DỰ ÁN THỰC TẾ
                </button>
                <button 
                  onClick={() => navigate('contact')} 
                  className="bg-transparent border border-white/50 py-4 px-10 font-bold uppercase tracking-widest hover:bg-white/10 transition-all active:scale-95"
                >
                  NHẬN TƯ VẤN
                </button>
              </div>
            </div>
          </section>

          <section className="bg-white py-20 border-b border-gray-100">
            <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
              {[
                { v: 15, l: 'NĂM KINH NGHIỆM' },
                { v: 250, l: 'CÔNG TRÌNH HOÀN THIỆN' },
                { v: 10, l: 'TỈNH THÀNH / QUỐC GIA' }
              ].map((s, i) => (
                <div key={i} className="flex flex-col items-center">
                  <Counter target={s.v} />
                  <div className="text-[10px] uppercase tracking-widest text-gray-400 mt-3 font-bold">{s.l}</div>
                </div>
              ))}
            </div>
          </section>

          <section id="services" className="py-24 bg-white border-b border-gray-50">
            <div className="container mx-auto px-6">
              <div className="text-center mb-16">
                 <h2 className="text-3xl md:text-4xl font-heading font-bold uppercase tracking-widest">DỊCH VỤ CUNG CẤP</h2>
                 <div className="w-20 h-1 bg-brand-primary mx-auto mt-6"></div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {SERVICES_BRIEF.map((s, i) => (
                  <div key={i} onClick={() => navigate('services')} className="group relative overflow-hidden h-[350px] cursor-pointer shadow-lg rounded-sm transition-all hover:-translate-y-2">
                    <img src={s.img} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt={s.title} />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent flex flex-col justify-end p-6">
                      <div className="text-brand-primary mb-3 transition-transform group-hover:-translate-y-1">{s.icon}</div>
                      <h3 className="text-[10px] md:text-xs font-bold text-white uppercase tracking-[0.15em] leading-tight">{s.title}</h3>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="py-20 bg-[#e0ddd2] text-gray-900">
            <div className="container mx-auto px-6">
              <div className="flex justify-center mb-16 overflow-x-auto scrollbar-hide pb-4">
                 <div className="inline-flex bg-white/40 p-1 rounded-sm border border-black/5 whitespace-nowrap shadow-sm">
                    {Object.keys(PROCESS_DATA).map((key) => (
                      <button key={key} onClick={() => setActiveProcessTab(key as keyof typeof PROCESS_DATA)} className={`px-5 py-3 text-[9px] md:text-[10px] font-bold uppercase tracking-[0.2em] transition-all ${activeProcessTab === key ? 'bg-brand-primary text-white shadow-lg' : 'text-gray-500 hover:text-brand-primary'}`}>
                        {PROCESS_DATA[key as keyof typeof PROCESS_DATA].label}
                      </button>
                    ))}
                 </div>
              </div>
              <div className="max-w-7xl mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {PROCESS_DATA[activeProcessTab].stages.map((stage, i) => (
                    <div key={i} className="relative group animate-fadeIn flex flex-col items-center text-center">
                       <div className="w-12 h-12 rounded-full bg-white border border-gray-200 flex items-center justify-center z-10 group-hover:border-brand-primary transition-all shadow-md mb-6">
                         <div className="text-gray-400 group-hover:text-brand-primary transition-all scale-75">{stage.icon}</div>
                       </div>
                       <div className="bg-white/60 backdrop-blur-sm p-8 rounded-sm border border-black/5 group-hover:border-brand-primary/20 transition-all flex flex-col items-center w-full h-full shadow-sm hover:shadow-2xl hover:bg-white">
                          <h5 className="text-[10px] font-bold text-brand-primary uppercase tracking-[0.3em] mb-3">{stage.title}</h5>
                          <h4 className="text-sm font-bold mb-4 uppercase tracking-widest min-h-[40px] flex items-center justify-center text-gray-800">{stage.subtitle}</h4>
                          <p className="text-gray-600 text-[11px] font-medium tracking-widest leading-relaxed mb-6">{stage.desc}</p>
                          {stage.pay && (
                            <div className="mt-auto flex items-center gap-2 bg-brand-primary/10 py-2 px-4 rounded-sm border border-brand-primary/10 w-fit">
                              <Coins className="w-3 h-3 text-brand-primary" />
                              <span className="text-[9px] font-bold text-brand-primary uppercase tracking-widest leading-none">THANH TOÁN: {stage.pay.replace('💰', '').trim()}</span>
                            </div>
                          )}
                       </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section id="projects" ref={projectsRef} className="py-24 bg-gray-50">
            <div className="container mx-auto px-6">
              <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                <div className="w-full md:w-1/2">
                  <h4 className="text-brand-primary font-bold text-xs uppercase tracking-[0.3em] mb-4">SHOWCASE</h4>
                  <h2 className="text-4xl font-heading font-bold uppercase tracking-widest">{activeHeader}</h2>
                </div>
                <div className="w-full md:w-1/2 flex justify-end">
                   <div className="flex flex-wrap gap-2 justify-end bg-white/80 p-2 border border-gray-100 rounded-sm shadow-sm">
                      {PROJECT_CATEGORIES.map(cat => (
                        <button key={cat.id} onClick={() => { setActiveProjectCategory(cat.id); setShowAllProjects(false); }} className={`px-4 py-2 text-[10px] font-bold uppercase tracking-widest transition-all ${activeProjectCategory === cat.id ? 'bg-brand-primary text-white shadow-sm' : 'text-gray-400 hover:text-brand-primary'}`}>
                          {cat.label}
                        </button>
                      ))}
                   </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {visibleProjects.map(p => (
                  <article key={p.id} onClick={() => openProjectDetail(p)} className="group cursor-pointer bg-white overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 rounded-sm">
                    <div className="relative overflow-hidden aspect-[4/3]">
                      <img src={p.gallery[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={p.title} />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="p-8 text-center">
                      <h3 className="text-xl font-bold mb-2 group-hover:text-brand-primary transition-colors uppercase">{p.title}</h3>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">{p.floors} • {p.area} • {p.style}</p>
                    </div>
                  </article>
                ))}
              </div>

              {!showAllProjects && filteredProjects.length > 3 && (
                <div className="flex justify-center mt-16">
                  <button 
                    onClick={() => setShowAllProjects(true)}
                    className="border-2 border-[#705d3f] text-[#705d3f] px-12 py-4 text-[12px] font-bold uppercase tracking-[0.3em] hover:bg-[#705d3f] hover:text-white transition-all rounded-sm shadow-md flex items-center gap-4 group"
                  >
                    XEM TẤT CẢ <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
                  </button>
                </div>
              )}
            </div>
          </section>
        </>
      )}

      {currentView === 'project_detail' && selectedProject && (
        <ProjectDetailView 
          project={selectedProject} 
          onBack={() => navigate('home')} 
          onContact={() => navigate('contact')}
        />
      )}
      {currentView === 'about' && <AboutUsView />}
      {currentView === 'services' && <ServicesView />}
      {currentView === 'handbook' && <HandbookView />}
      {currentView === 'contact' && <ContactView />}

      <footer className="text-white pt-24 pb-12 relative overflow-hidden" style={{ backgroundColor: 'rgba(45, 35, 24, 0.95)', backdropFilter: 'blur(20px)' }}>
        <div className="container mx-auto px-6 grid lg:grid-cols-3 gap-16 relative z-10">
          <div className="space-y-10">
            <div className="flex items-center gap-3">
               <img src="https://lh3.googleusercontent.com/d/18wUo0JZ3MWDLKqjRqFsS6PB5jDbZYNsA" className="h-10 brightness-0 invert" alt="NM Studio Logo Footer" />
               <div className="text-sm font-heading font-bold tracking-[0.2em] uppercase">N&M Studio</div>
            </div>
            <p className="text-[11px] text-white/70 leading-relaxed font-light uppercase tracking-widest max-w-sm">
              NM Studio – Khởi tạo giá trị từ tâm huyết và kinh nghiệm. Chúng tôi đồng hành cùng gia chủ xây dựng tổ ấm hoàn hảo nhất.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Youtube, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand-primary hover:border-brand-primary transition-all active:scale-90"><Icon className="w-4 h-4" /></a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.3em] mb-10 pb-3 border-b border-white/10 w-fit">LIÊN KẾT</h4>
            <ul className="space-y-4 text-[11px] text-white/70 font-bold tracking-[0.2em] uppercase">
              {NAV_ITEMS.map((item, i) => (
                <li key={i}><a href="#" onClick={(e) => { e.preventDefault(); navigate(item.view); }} className="hover:text-brand-primary transition-colors inline-block">{item.label}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.3em] mb-10 pb-3 border-b border-white/10 w-fit">THÔNG TIN</h4>
            <div className="space-y-6 text-[11px] text-white/70 font-medium tracking-widest leading-loose">
              <p className="flex gap-4 uppercase"><MapPin className="w-4 h-4 shrink-0 text-brand-primary" /> số 10 ngõ 142 Hào Nam, Đống Đa, Hà Nội</p>
              <p className="flex gap-4 uppercase"><Phone className="w-4 h-4 shrink-0 text-brand-primary" /> {ZALO_CONFIG.phoneNumber}</p>
              <p className="flex gap-4 uppercase"><Mail className="w-4 h-4 shrink-0 text-brand-primary" /> nghiavu2011@gmail.com</p>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-6 mt-20 pt-8 border-t border-white/5 text-center text-[10px] text-white/40 uppercase tracking-[0.4em]">
          © 2024 N&M Studio. Designed with excellence for Architecture & Interiors.
        </div>
      </footer>
      
      <style>{`
        @keyframes breathe {
          0% { transform: scale(1); }
          50% { transform: scale(1.04); }
          100% { transform: scale(1); }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-breathe { animation: breathe 15s ease-in-out infinite; }
        .animate-fadeIn { animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        
        select {
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
          background-position: right 1rem center;
          background-repeat: no-repeat;
          background-size: 1rem;
        }
      `}</style>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
